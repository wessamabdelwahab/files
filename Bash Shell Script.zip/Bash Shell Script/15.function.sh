#!/bin/bash
#Declaring function
display() {
        echo DevOps is not just: $1
}

#Calling a function
display "Source Code Management (SCM)"
display "Continuous Integration (CI)"
display "Infrastructure as Code (IaC)"
display "Configuration Management (CM)"
