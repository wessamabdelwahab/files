#!/bin/bash
if [ -x /etc/passwd ]; then
        echo "file executable"
else
        echo "file not executable"
fi
