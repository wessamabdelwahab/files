#!/bin/bash
echo Give two strings to compare
echo Enter the first string
read str1
echo Enter the second string
read str2
if [ "$str1" = " $str2" ]; then
        echo "The first string: $str1 is the same as the second string: $str2"
else
        echo "The first string: $str1 is not the same as the second string: $str2"
fi
