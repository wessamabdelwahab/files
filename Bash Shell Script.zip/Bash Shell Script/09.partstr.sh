#!/bin/bash
name=Wessam.Abdelwahab
first=${name:0:6}; echo first name = $first
last=${name#*.}; echo last name = $last
