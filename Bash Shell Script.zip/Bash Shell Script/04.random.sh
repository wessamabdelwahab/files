#!/bin/bash
for n in 1 2 3 4 5
do echo A New Number is $RANDOM
done
