#!/bin/bash
if [[ -f /etc/passwd ]]
then
  echo "file exist"
else
  echo "file does not exist"
fi
