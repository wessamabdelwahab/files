#!/bin/bash
TEMPFILE=$(mktemp /tmp/tempfile.XXXXXXXX)
echo $TEMPFILE
TEMPDIR=$(mktemp -d /tmp/tempdir.XXXXXXX)
echo $TEMPDIR
