#!/bin/bash
#Interactive reading of a variable
echo "Enter Your Name"
#The value is stored in a temporary variable, name
read name
#Reference the value of a shell variable
#by using a $ in front of the variable name
#and display variable input
echo The name given was: $name
