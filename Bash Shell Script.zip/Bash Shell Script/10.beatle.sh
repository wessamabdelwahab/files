#!/bin/bash
echo Give your first name '(First Letter must be Capital)'
#Pull in an environment variable with the read statement.
read name
#Compare strings using the operator == (equal)
if [ "$name" == John ] ; then
        echo Hello $name
elif [ "$name" == Ringo ] ; then
       echo Hello "$name"
#Using the Boolean Operator || (OR)
elif [ "$name" == Paul ] || [ "$name" == George ] ; then
        echo Hello "$name"
else
        echo $name, You are not a Beatle!
fi
