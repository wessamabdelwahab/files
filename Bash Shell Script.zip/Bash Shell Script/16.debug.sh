#!/bin/bash
if [ "$1" != "" ]; then set -x ; fi
echo "Do you like DevOps? Type Y OR N"
read response
case "$response" in
        "y" | "Y" ) echo "You are awesome!" ;;
        "n" | "N" ) echo "I hope you will like it soon..." ;;
        *) echo "You have to give an answer!" ;;
esac
