#single quote 
print('Ansible is a Configuration Management tool written in Python')
