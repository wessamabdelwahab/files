print( 22 % 7)
