#Check if String end with (prepcourse)
print("This is a Python prepcourse.".endswith("prepcourse."))
