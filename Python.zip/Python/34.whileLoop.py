#while loop
i = 0
#while Ture making an infinite loop until a condition is met
while True:
    i = i +1
    if i == 2:
        print("Skipping 2")
        #continue stops current iteration and continues with next one
        continue
    if i == 5:
        print("Breaking")
        #break end a while loop prematurely 
        break
    print(i)
print("Finished")
