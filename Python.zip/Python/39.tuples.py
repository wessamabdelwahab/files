#Tuple
devops = ("SCM", "IaC", "CM")
#print the first item in Tuple
print(devops[0])
#Tuples can’t be changed, they are immutable 
devops[1] = "CI"