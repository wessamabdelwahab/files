try:
    #Open file in read mode
    f = open("file.txt")
except:
    #print error message in case of an exception
    print("Something went wrong")
finally:
    #This ensures that the file is closed, even if error occurs
    f.close() 
