#Newlines using three quotes (""")
print("""Continuous Integration
Continuous Delivery
Continuous Deployment""")
