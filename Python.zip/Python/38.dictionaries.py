#dictionary key:value pair
devops = {"SCM": 1, "IaC": 2, "CM": [3, 4]}
#print the value of "SCM" key
print(devops["SCM"])
#print the value of " IaC" key
print(devops["IaC"])
#print the value of " CM " key
print(devops["CM"])
#Change the value of " IaC " key
devops["IaC"] = 50
#Add key " CI " and value for it
devops["CI"] = 5
#Prints the dictionary key:value pair
print(devops)
#Check if key "XYZ" in devops dictionary
print("XYZ" in devops)
#The get method gets the value of  "SCM" key
print(devops.get("SCM"))
