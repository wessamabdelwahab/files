#Replace (You)  with (Python)
print("Hello You".replace("You", "Python"))
