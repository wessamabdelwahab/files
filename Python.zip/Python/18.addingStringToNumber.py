#Adding string to number
print("Python " + 0)
