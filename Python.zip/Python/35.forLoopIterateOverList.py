#for loop iterate over a list of strings
words = ["Source Control Management (SCM)", "Infrastructure as Code (IaC)", "Configuration Management (CM)"]
for word in words:
    print(word + "!")
