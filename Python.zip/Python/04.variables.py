age = 30
print(age)
Age = 40
print(Age*3)
