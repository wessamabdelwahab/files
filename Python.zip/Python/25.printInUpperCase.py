#prints the sentence in upper case
print("This is a Python prepcourse.".upper())
