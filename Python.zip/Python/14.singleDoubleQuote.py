#single quote included in double quote string 
print ("DevOp\'s is Awesome! ")
