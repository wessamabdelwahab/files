#multiply string by integer
print("Python and DevOps work nicely together" * 2)
