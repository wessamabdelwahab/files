x = 'Python'
print(x)
x += " DevOps "
print(x)
x = x *  3
print(x)
#using in-Place Operators for more concise code
x *= 3
print(x)
