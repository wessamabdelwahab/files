# dividing integer by 0 will throw ZeroDivisionError exception
num1 = 100
num2 = 0
print(num1/num2)