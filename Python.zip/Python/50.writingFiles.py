msg = "Python is awesome!"
#open file in write mode ‘w’ for writing the message to a file. 
file = open("newfile.txt", "w")
amount_written = file.write(msg)
file.close()

#open file in read mode ‘r’ for reading the message from the file. 
file = open("newfile.txt", "r")
print("Checking contents...")
#reading the content using read method
print("Reading contents: " + file.read())
#counting the content in the file
print("Counting contents: " + str(amount_written))
print("Finished")
file.close()
