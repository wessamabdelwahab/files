#import module math just for demonstration
import math

#The from... import used to import certain function from a module using as keyword
from math import sqrt as square_root
print(square_root(25))
