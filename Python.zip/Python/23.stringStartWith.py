#Check if String start with (This)
print("This is a Python prepcourse.".startswith("This"))
