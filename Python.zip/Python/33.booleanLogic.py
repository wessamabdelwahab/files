#Boolean Logic
python = 20
devops = 10
#and operator
if python > 15 and devops > 10:
  print ("Great")
#or operator
elif python < 15 or devops < 10:
  print ("Excellent")
#not operator
elif not(python < 15 or devops < 10):
  print ("Awesome")
else:
  print ("o(")
