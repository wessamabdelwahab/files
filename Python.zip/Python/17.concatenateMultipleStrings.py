#concatenate multiple strings
print("Python " + "is " + "awesome " + ":0")