#!/usr/bin/env python3
#open file in read mode ‘r’ for reading the file. 
file = open("readfile.txt", "r")
print("Reading contents: ")
#reading the content using read method
print(file.read())
print("Finished")
file.close()
