print(50 + 50)
print(50 - 25)
print(100 * 5)
print(100 / 5)
