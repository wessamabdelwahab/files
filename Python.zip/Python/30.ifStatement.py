#Nested If statement
python = 20
if python > 15 :
    print ("20 is greater than 15")
    if python < 40:
        print ("20 is less than 40") 
