#Define a function that takes two arguments
def my_func(word, variable):
    #Using function argument as variable inside the function definition
    variable += 1
    print(word + "!" , str(variable) + "%")

#Calling the function multiple times with different arguments
my_func("Python" , 99)
my_func("DevOps" , 199)
