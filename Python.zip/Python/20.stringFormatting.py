#Uses a string's format method to substitute a number of arguments in a string.
str="{c}, {b}, {a}".format(a=5, b=9, c=7) 
print(str)
