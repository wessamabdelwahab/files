#prints the sentence in lower case
print("THIS IS A PYTHON PREPCOURSE.".lower())
