#The function definition
def my_func():
    print("Source Control Management (SCM)")
    print("Infrastructure as Code (IaC)")
    print("Configuration Management (CM)")

#Calling the function multiple times
my_func()
print("\n")
my_func()
