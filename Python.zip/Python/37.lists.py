number = 100
#List
words = ["Python", "is", "Awesome", [number, 20]]
# Accessing the first list item
print(words[0])
# Accessing the second list item
print(words[1])
# Accessing the third list item
print(words[2])
# Accessing the first list item in the fourth item list (nested list)
print(words[3][0])