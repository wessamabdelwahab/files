#try block contains code that might throw an exception
try:
    num1 = 100
    num2 = 0
    print(num1/num2)
#when an exception occurs, the code in the except block run
except (ZeroDivisionError):
    print("An exception occur due to zero division")
    #raise exceptions 
    raise
#the finally statement code will run no matter what errors occur
finally:
    print("This finally statement will always run")