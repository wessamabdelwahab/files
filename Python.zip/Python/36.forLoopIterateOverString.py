#for loop iterate over a string and count the number of ‘n’ letters in devops string
devops ='Continuous Integration'
count = 0
for x in devops:
    if(x == 'n'):
      count += 1
print("Number of 'n' letters in devops string: " + str (count))
