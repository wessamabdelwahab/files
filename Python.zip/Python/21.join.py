#Join (SCM, IaC, CM) strings with (*) as a separator 
print(" * ".join(["SCM", "IaC", "CM"]))
