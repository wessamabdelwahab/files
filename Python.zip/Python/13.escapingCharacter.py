#escaping a character by placing a backslash before it.  
print ('DevOp\'s is Awesome! ')
