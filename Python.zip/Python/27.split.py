#split (SCM, IaC, CM) strings based on (,) separator into a list
print("SCM, IaC, CM".split(", "))
