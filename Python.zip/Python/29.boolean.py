#equal operator ==
print (1 == 1)
#not equal operator !=
print ("Three" != "Five")
#greater than > 
print (3 > 5)
#smaller than <
print (5 < 3)
#greater than or equal >=
print (6 >= 5)
#smaller than or equal <=
print (3 <= 3)
