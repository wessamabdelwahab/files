#elif Statement
python = 20
if python < 15:
    print("15 is less than 20")
elif python > 15:
    print("20 is greater than 15")
else:
   print("None of the above")
