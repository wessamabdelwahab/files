#returns a sequence of numbers start with 0 and stop before 10
numbers = list(range(10))
print(numbers)
print('\n')

#returns a sequence of numbers start with 2 and stop before 8
numbers = list(range(2, 8))
print(numbers)
print('\n')

#returns a sequence of numbers start with 3 and interval of 2 and stop before 21
numbers = list(range(3, 21, 2))
print(numbers)
print('\n')

#for loop to print Python 5 times 
for i in range(5):
    print("Python!")
