#get the name using input function
name = input("Enter your name: ")
#get the age using input function and convert the string to a number
age = int(input("What is your age? "))
print(age)
#convert the input (age) number to a string
print("Hi, " + name + " your age as string is " + str(age) + " years old")
