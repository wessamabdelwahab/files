#Newlines using \n
print('Continuous Integration \nContinuous Delivery \nContinuous Deployment')