#"Python " + "is " + "awesome"
print("Python " + "is " + "awesome")