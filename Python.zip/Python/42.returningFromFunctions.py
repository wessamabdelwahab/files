# Define a function that return the sum of two numbers 
def add_numbers(x, y):
    total = x + y
    return total
    #Any code after the return statement will not be executed.
    print("This will not be printed")

#Calling the function
sum_numbers = add_numbers
print(sum_numbers(80, 20))
