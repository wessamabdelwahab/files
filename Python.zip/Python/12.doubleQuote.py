#double quote 
print ("DevOps is Awesome!")
